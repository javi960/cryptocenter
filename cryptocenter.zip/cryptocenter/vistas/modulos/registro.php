<body class="hold-transition register-page cuerpo">
  <div class="register-box">
    <div class="register-logo">
      <a href="inicio"><b>Crypto</b>Center</a>
    </div>

    <div class="card">
      <div class="card-body register-card-body">
        <p class="login-box-msg">Registrar nuevo miembro</p>

        <form method="post" id="registroUsuario">
          <div class="input-group mb-3">
            <input type="text" name="usuario" id="usuario" class="form-control" placeholder="nombre de usuario" required>
            <div class="input-group-append">
              <div class="input-group-text">
                <span class="fas fa-user"></span>
              </div>
            </div>
          </div>
          <span id="spanUsuario" class='text-danger' style="display: none;">Nombre de Usuario en uso</span>
          <div class="input-group mb-3">
            <input type="email" name="email" id="email" class="form-control" placeholder="Email" required>
            <div class="input-group-append">
              <div class="input-group-text">
                <span class="fas fa-envelope"></span>
              </div>
            </div>
          </div>
          <span id="spanEmail" class='error invalid-feedback' style="display: none;">Email en uso</span>
          <div class="input-group mb-3">
            <input type="password" name="contraseña" id="contraseña" class="form-control" placeholder="Contraseña" pattern="^(?=.*\d)(?=.*[\u0021-\u002b\u003c-\u0040])(?=.*[A-Z])(?=.*[a-z])\S{8,16}$" required>
            <div class="input-group-append">
              <div class="input-group-text">
                <span class="fas fa-lock"></span>
              </div>
            </div>
          </div>
          <div class="input-group mb-3">
            <input type="password" name="rcontraseña" id="rcontraseña" class="form-control" placeholder="Repite la Contraseña" pattern="^(?=.*\d)(?=.*[\u0021-\u002b\u003c-\u0040])(?=.*[A-Z])(?=.*[a-z])\S{8,16}$" required>
            <div class="input-group-append">
              <div class="input-group-text">
                <span class="fas fa-lock"></span>
              </div>
            </div>
          </div>
          <ul>
            <li><small>La contraseña debe tener al entre 8 y 16 caracteres</small></li>
            <li><small>Al menos un dígito</small></li>
            <li><small>Al menos una minúscula</small></li>
            <li><small>Al menos una mayúscula</small></li>
            <li><small>Al menos un caracter no alfanumérico</small></li>
          </ul>
          <div class="row">
            <div class="col-8">
              <div class="icheck-primary">
                <input type="checkbox" id="agreeTerms" name="terms" value="agree" required>
                <label for="agreeTerms">
                  Acepto los <a href="#" data-toggle="modal" data-target="#modalTerminos">terminos</a>
                </label>
              </div>
            </div>
            <!-- /.col -->
            <div class="col-4">
              <button type="submit" id="BotonRegistro" class="btn btn-primary btn-block">Registrar</button>
            </div>
            <!-- /.col -->
          </div>
          <?php
          $registro = new ControladorUsuarios();
          $registro->ctrCrearUsuario();
          ?>

        </form>

        <a href="login" class="text-center">Ya soy Miembro</a>
      </div>
      <!-- /.form-box -->
    </div><!-- /.card -->
  </div>
  <!-- /.register-box -->
  <!-- Modal AGREGAR USUARIOS-->

  <!-- Modal -->
  <div id="modalTerminos" class="modal fade" role="dialog">
    <div class="modal-dialog modal-lg">

      <!-- Modal content-->
      <div class="modal-content">
        <div class="modal-header">
          <h5 class="modal-title" id="exampleModalLabel">Terminos</h5>
          <button type="button" class="close" data-dismiss="modal" aria-label="Close">
            <span aria-hidden="true">&times;</span>
          </button>
        </div>
        <div class="modal-body">
          <p>Lorem ipsum dolor sit amet consectetur adipiscing elit pharetra, vivamus venenatis per vulputate euismod et proin, non risus dignissim luctus eu aptent interdum. Taciti nec senectus duis diam porttitor tempus sem hac platea leo maecenas non phasellus eu felis vivamus class, in quisque dignissim auctor suspendisse vulputate malesuada litora fringilla fames porta condimentum elementum dictum blandit sollicitudin. Vivamus diam quis natoque libero dictumst consequat posuere lacinia est nulla nunc, dignissim donec scelerisque ridiculus proin velit potenti platea vel tempus eget tellus, sollicitudin nostra penatibus erat fames mauris taciti eu nec pulvinar. Iaculis faucibus nisl ligula ornare et proin nisi facilisi senectus porttitor mattis, rutrum litora aliquam fringilla justo hendrerit vivamus odio nostra porta euismod, a nullam semper pulvinar urna ante imperdiet sociis pretium conubia.</p>
          <p>Faucibus nunc cras conubia lectus nisl convallis hac habitant, egestas scelerisque praesent ullamcorper ornare suspendisse sociis vehicula malesuada, laoreet sem fermentum sed pulvinar leo mauris. Tellus lectus habitasse netus vestibulum tincidunt torquent enim platea tempus facilisis, cum gravida fringilla nunc facilisi quis vulputate natoque nisl, venenatis primis porta nostra vitae ridiculus quisque nulla iaculis. Tellus aliquam mattis volutpat sagittis ultrices diam lectus penatibus, odio ut proin bibendum platea netus suscipit class, pellentesque et potenti natoque nostra luctus phasellus.</p>
          <p>Semper tincidunt aenean eleifend at ad massa nulla primis rhoncus phasellus, cum taciti habitasse velit lacinia conubia sodales tellus habitant. Torquent tellus ante porta vestibulum himenaeos luctus purus elementum class varius, cursus morbi quam egestas nulla bibendum eleifend aptent congue, mollis tincidunt donec eget facilisis fringilla iaculis per ut. Laoreet nostra suspendisse habitant tincidunt fermentum at rutrum diam lacinia purus, metus semper mollis interdum class litora luctus viverra orci, pharetra eleifend facilisi tristique risus posuere nec lectus molestie. Risus nisl pretium metus urna euismod eleifend et senectus, mus pulvinar nisi vehicula aliquet molestie placerat curae ad, convallis duis congue ullamcorper ligula conubia class.</p>
          <p>Inceptos cubilia nullam hendrerit netus habitasse integer enim nascetur erat ultrices aliquet elementum, turpis tincidunt ligula fames suscipit bibendum vestibulum dapibus platea at. Vitae sed malesuada fusce cras montes senectus ad et dui duis pulvinar ante, ut tortor tristique ultrices cubilia mi hendrerit ullamcorper eget tempor interdum lectus, class dis posuere praesent nisl netus leo curabitur vivamus nec sociis. Nibh torquent bibendum pretium auctor conubia porttitor risus cum, lectus odio suscipit tempus varius praesent metus eget, ultricies maecenas curabitur urna senectus fringilla erat. Placerat luctus pellentesque convallis laoreet velit vestibulum cursus ornare, euismod ac tristique magna sem curae dis, per in facilisis conubia felis penatibus aliquam.</p>
          <p>Ligula etiam orci lectus erat imperdiet massa curae, diam accumsan nisl condimentum blandit arcu himenaeos tristique, interdum congue at sociosqu cubilia euismod. Iaculis ad non tincidunt et ut, at massa aliquam magnis, pretium fames nibh purus. Iaculis lobortis montes vivamus tortor potenti commodo mi rhoncus euismod habitant eget blandit non mattis, ornare mus eu erat nulla fermentum facilisis sed class rutrum posuere morbi. Sed augue eleifend sociis cras in nulla dictum commodo cubilia, ut curabitur lobortis eros posuere integer ac convallis lacus, placerat senectus nam phasellus taciti nec ultricies at.</p>
          <p>Suscipit quam primis gravida erat metus risus sagittis dapibus, penatibus id taciti proin velit praesent lobortis consequat, viverra vulputate imperdiet habitant varius per tempor. Mus posuere nisl inceptos tincidunt sed integer accumsan interdum, magna eros blandit orci ligula dis et dictum ullamcorper, commodo cum vulputate praesent facilisis risus nec. Aenean fringilla per netus dignissim lacus himenaeos vivamus parturient tempor, massa elementum risus cubilia malesuada egestas eros ornare, interdum nisi taciti ad porta natoque porttitor morbi. Himenaeos convallis porta nulla eros semper auctor penatibus eget, nascetur urna nullam primis fermentum cum sociosqu conubia, hac cursus tincidunt integer vitae lacus proin.</p>
          <p>Augue aliquet urna vitae gravida imperdiet eu sociis consequat nibh, nisl hac conubia feugiat vivamus aenean metus et non accumsan, risus hendrerit suscipit mi at auctor fames nullam. Potenti ligula et duis montes congue accumsan dis dictum vehicula, nam praesent elementum hac etiam curabitur dictumst porttitor. Ante sociis convallis montes metus tellus scelerisque luctus rutrum id, torquent faucibus elementum eleifend volutpat nisl penatibus felis, leo varius litora a aliquam interdum mollis vulputate. Tempus ad fames lectus augue diam placerat cras neque, congue hendrerit nec conubia ullamcorper in enim, praesent consequat magna iaculis lobortis curabitur cursus.</p>
          <p>Etiam volutpat accumsan lobortis in diam vehicula viverra sodales, rhoncus ac lacinia malesuada hac sapien platea consequat lacus, congue habitant per fusce maecenas eget nulla. Suspendisse cras et tellus habitant condimentum porttitor a platea vulputate, tempus sapien libero leo per quisque risus penatibus montes, natoque accumsan cum mi ridiculus egestas ante scelerisque. Habitasse nostra non fermentum potenti facilisis dui molestie, condimentum habitant commodo egestas dictum mattis vitae, euismod bibendum dictumst quisque laoreet diam. Pharetra vehicula magna sociis laoreet tellus nunc fusce ante donec nisl, consequat quisque natoque curae netus fringilla et massa.</p>
        </div>
        <div class="modal-footer">
          <button type="button" class="btn btn-secondary" data-dismiss="modal">Cerrar</button>
        </div>
      </div>

    </div>
  </div>

  <script src="vistas/js/registro.js"></script>