<div class="content-wrapper">
    <!-- Content Header (Page header) -->
    <section class="content-header">
        <div class="container-fluid">
            <div class="row mb-2">
                <div class="col-sm-6">
                    <h1>Compras</h1>
                </div>
            </div>
        </div><!-- /.container-fluid -->
    </section>


    <!-- Main content -->
    <section class="content">
        <div class="container-fluid">
            <div class="row">
                <div class="col-12">
                    <div class="card">

                        <!-- /.card-header -->
                        <div class="card-body">
                            <table class="table table-hover">
                                <thead class="thead-dark">
                                    <tr>
                                        <th>Identificador</th>
                                        <th>Nombre</th>
                                        <th>Valor en Dolares</th>
                                        <th>Beneficio de compra para la plataforma</th>
                                        <th>Más Acciones</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php
                                    $coin = ControladorMonedas::ctrMostrarMonedas();
                                    $valor = $_SESSION["usuario"];
                                    $lista = ControladorMonedas::ctrMostrarMonedasSUsuario2($valor);
                                    
                                    foreach ($lista as $key => $value) {
                                        foreach ($coin as $key2 => $value2) {
                                            $ElArrayMonedas = get_object_vars($value2);
                                            if ($value["id_moneda"] == $ElArrayMonedas["asset_id"]) {
                                                if ($ElArrayMonedas["price_usd"]>1) {
                                                    $valordolar = round($ElArrayMonedas["price_usd"], 2);
                                                }else {
                                                    $valordolar = $ElArrayMonedas["price_usd"];
                                                }
                                                $valordolar =str_replace(".",",",$valordolar);
                                                echo '<tr>
                                                    <td><img src="vistas/img/'.$value["id_moneda"].'.png"> ' . $value["id_moneda"] . '</td>
                                                    <td>' . $value["nombre"] . '</td>
                                                    <td>' . $valordolar. ' $</td>
                                                    <td>' . $value["BenfCompra"] . '%</td>
                                                    <td class="row d-flex justify-content-center">
                                                        <button class="btn btn-success btnComprarMoneda" 
                                                        Nmoneda="' . $value["id_moneda"] .'"
                                                        data-toggle="modal" data-target="#modalComprarMoneda">Comprar</button>
                                                    </td>
                                                    </tr>';
                                            }
                                        }
                                    }
                                    ?>
                                </tbody>
                            </table>
                        </div>
                        <!-- /.card-body -->
                    </div>
                    <!-- /.card -->
                </div>
                <!-- /.col -->
            </div>
            <!-- /.row -->
        </div>
        <!-- /.container-fluid -->
    </section>
    <!-- /.content -->
</div>

<!-- Modal COMPRAR MONEDAS-->

<!-- Modal -->
<div id="modalComprarMoneda" class="modal fade" role="dialog">
    <div class="modal-dialog">

        <!-- Modal content-->
        <div class="modal-content">
            <form method="post">

                <div class="modal-header" style="background: #3c8dbc; color:white;">
                    <h5 class="modal-title" id="exampleModalLabel">Comprar Moneda</h5>
                    <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                        <span aria-hidden="true">&times;</span>
                    </button>
                </div>
                <div class="modal-body">
                    <div class="box-body">
                        <label>¿Cuanto dinero deseas canjear?</label>
                        <div class="input-group mb-3">                            
                            <input type="number" name="CanjeMoneda" class="form-control" min="0" value="0">
                            <div class="input-group-append">
                                <div class="input-group-text">
                                    <span class="fas fa-coins"></span>
                                </div>
                            </div>
                        </div>
                        <input type="hidden" name="nusuario" value="<?php echo $_SESSION['usuario']; ?>">
                        <input type="hidden" name="idmoneda" id="idmoneda">
                    </div>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-outline-secondary pull-left" data-dismiss="modal">Cancelar</button>
                    <button type="submit" class="btn btn-primary">Aceptar</button>
                </div>


                <?php

                    $comprarMonedas= new ControladorCompraVenta();
                    $comprarMonedas -> ctrComprarMonedas();
                ?>


            </form>
        </div>

    </div>
</div>
