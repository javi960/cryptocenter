<div class="content-wrapper">
    <!-- Content Header (Page header) -->
    <section class="content-header">
        <div class="container-fluid">
            <div class="row mb-2">
                <div class="col-sm-6">
                    <h1>Billetera</h1>
                </div>
            </div>
        </div><!-- /.container-fluid -->
    </section>


    <!-- Main content -->
    <section class="content">
        <div class="container-fluid">
            <div class="row">
                <div class="col-12">
                    <div class="card">

                        <!-- /.card-header -->
                        <div class="card-body">
                            <table class="table table-hover">
                                <thead class="thead-dark">
                                    <tr>
                                        <th>Identificador</th>
                                        <th>Nombre</th>
                                        <th>Valor en Dolares</th>
                                        <th>Cantidad</th>
                                        <th>Más Acciones</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php
                                    $coin = ControladorMonedas::ctrMostrarMonedas();
                                    $valor = $_SESSION["usuario"];
                                    $lista = ControladorMonedas::ctrMostrarMonedasbilletera($valor);
                                    
                                    foreach ($lista as $key => $value) {
                                        foreach ($coin as $key2 => $value2) {
                                            $ElArrayMonedas = get_object_vars($value2);
                                            if ($value["id_moneda"] == $ElArrayMonedas["asset_id"]) {
                                                $datos2 = array(
                                                    "id_moneda" =>  $value["id_moneda"],
                                                    "n_usuario" => $valor
                                                );
                                                if ($ElArrayMonedas["price_usd"]>1) {
                                                    $valordolar = round($ElArrayMonedas["price_usd"], 2);
                                                }else {
                                                    $valordolar = $ElArrayMonedas["price_usd"];
                                                }
                                                $valordolar =str_replace(".",",",$valordolar);
                                                $botones="";
                                                if ($value["activo"]=='1') {
                                                    $botones='<button class="btn btn-success btnComprarMoneda" 
                                                    Nmoneda="' . $value["id_moneda"] . '"
                                                    data-toggle="modal" data-target="#modalComprarMoneda">Comprar</button>
                                                    <button class="btn btn-info btnVenderMoneda" 
                                                    Nmoneda="' . $value["id_moneda"] . '"
                                                    data-toggle="modal" data-target="#modalVenderMoneda">Vender</button>
                                                    <button class="btn btn-warning btnDescargarMoneda" 
                                                    Dmoneda="' . $value["id_moneda"] . '-' . $_SESSION['usuario'] . '">Descargar</button>';
                                                }else {
                                                    $valordolar=0;
                                                    $botones='<button class="btn btn-warning btnDescargarMoneda" 
                                                    Dmoneda="' . $value["id_moneda"] . '-' . $_SESSION['usuario'] . '">Descargar</button>';
                                                }
                                                $cantidadMoneda = ModeloCompraVenta::MdlSelectMonedasCartera($datos2);
                                                if ($cantidadMoneda != null) {
                                                    $cantidadMonedas=str_replace(".",",",$cantidadMoneda['cantidad'] );
                                                    echo '<tr>
                                                        <td><img src="vistas/img/'.$value["id_moneda"].'.png"> ' . $value["id_moneda"] . '</td>
                                                        <td>' . $value["nombre"] . '</td>
                                                        <td>' . $valordolar . ' $</td>
                                                        <td>' . $cantidadMonedas . '</td>
                                                        <td class="row d-flex justify-content-center btn-group">
                                                            ' . $botones . '
                                                        </td>
                                                        </tr>';
                                                }
                                                
                                            }
                                        }
                                    }
                                    ?>
                                </tbody>
                            </table>
                        </div>
                        <!-- /.card-body -->
                    </div>
                    <!-- /.card -->
                </div>
                <!-- /.col -->
            </div>
            <!-- /.row -->
        </div>
        <!-- /.container-fluid -->
    </section>
    <!-- /.content -->
</div>

<!-- Modal COMPRAR MONEDAS-->

<!-- Modal -->
<div id="modalComprarMoneda" class="modal fade" role="dialog">
    <div class="modal-dialog">

        <!-- Modal content-->
        <div class="modal-content">
            <form method="post">

                <div class="modal-header" style="background: #3c8dbc; color:white;">
                    <h5 class="modal-title" id="exampleModalLabel">Comprar Moneda</h5>
                    <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                        <span aria-hidden="true">&times;</span>
                    </button>
                </div>
                <div class="modal-body">
                    <div class="box-body">
                        <label>¿Cuanto dinero deseas canjear?</label>
                        <div class="input-group mb-3">                            
                            <input type="number" name="CanjeMoneda" class="form-control" min="0" value="0">
                            <div class="input-group-append">
                                <div class="input-group-text">
                                    <span class="fas fa-coins"></span>
                                </div>
                            </div>
                        </div>
                        <input type="hidden" name="nusuario" value="<?php echo $_SESSION['usuario']; ?>">
                        <input type="hidden" name="idmoneda" id="idmoneda">
                    </div>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-outline-secondary pull-left" data-dismiss="modal">Cancelar</button>
                    <button type="submit" class="btn btn-primary">Aceptar</button>
                </div>


                <?php

                    $comprarMonedas= new ControladorCompraVenta();
                    $comprarMonedas -> ctrComprarMonedas();
                ?>


            </form>
        </div>

    </div>
</div>

<!-- Modal VENDER MONEDAS-->

<!-- Modal -->
<div id="modalVenderMoneda" class="modal fade" role="dialog">
    <div class="modal-dialog">

        <!-- Modal content-->
        <div class="modal-content">
            <form method="post">

                <div class="modal-header" style="background: #3c8dbc; color:white;">
                    <h5 class="modal-title" id="exampleModalLabel">Vender Moneda</h5>
                    <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                        <span aria-hidden="true">&times;</span>
                    </button>
                </div>
                <div class="modal-body">
                    <div class="box-body">
                        <label>¿Cuantas monedas deseas vender?</label>
                        
                        <div class="input-group mb-3">                            
                        <input type="number" name="VentaMoneda" id="VentaMoneda" class="form-control" step="any" min="0" value="0" max="1000">
                            <div class="input-group-append">
                                <div class="input-group-text">
                                    <span id="cantidadM"></span>
                                </div>
                            </div>
                        </div>
                        <input type="hidden" name="Vnusuario" value="<?php echo $_SESSION['usuario']; ?>">
                        <input type="hidden" name="Vidmoneda" id="Vidmoneda">
                    </div>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-outline-secondary pull-left" data-dismiss="modal">Cancelar</button>
                    <button type="submit" class="btn btn-primary">Aceptar</button>
                </div>


                <?php

                    $VenderMonedas= new ControladorCompraVenta();
                    $VenderMonedas -> ctrVenderMonedas();
                ?>


            </form>
        </div>

    </div>
</div>