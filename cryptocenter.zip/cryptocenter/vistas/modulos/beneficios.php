<!-- Content Wrapper. Contains page content -->
<div class="content-wrapper">
    <!-- Content Header (Page header) -->
    <section class="content-header">
        <div class="container-fluid">
            <div class="row mb-2">
                <div class="col-sm-6">
                    <h1>Configuración de Beneficios</h1>
                </div>
            </div>
        </div><!-- /.container-fluid -->
    </section>

    <!-- Main content -->
    <section class="content">
        <div class="container-fluid">

            <div class="row">
                <div class="col-md-6">
                    <!-- Line chart -->
                    <div class="card card-primary card-outline">
                        <div class="card-header">
                            <h3 class="card-title">
                                <i class="fas fa-hand-holding-usd"></i>
                                Configurar Beneficios
                            </h3>

                            <div class="card-tools">
                                <button type="button" class="btn btn-tool" data-card-widget="collapse">
                                    <i class="fas fa-minus"></i>
                                </button>
                                <button type="button" class="btn btn-tool" data-card-widget="remove">
                                    <i class="fas fa-times"></i>
                                </button>
                            </div>
                        </div>
                        <div class="card-body">
                            <table class="table table-hover">
                                <thead class="thead-dark">
                                    <tr>
                                        <th>Identificador</th>
                                        <th>Beneficio Compra</th>
                                        <th>Beneficio venta</th>
                                        <th>Editar Beneficios</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php
                                    $monedas = ControladorMonedas::ctrMostrarMonedasBase(null, null);
                                    foreach ($monedas as $key => $value) {
                                        if ($value["activo"] == '1') {
                                            $botonEditar = '<button class="btn btn-warning btnEditarBeneficio"
                                            data-toggle="modal" data-target="#modalEditarBeneficio" 
                                            Identificadormoneda="' . $value["id_moneda"] . '">Editar</button>';

                                            echo '<tr>
                                            <td>
                                            ' . $value["id_moneda"] . '</td>
                                            <td>' . $value["BenfCompra"] . '</td>
                                            <td>' . $value["BenfVenta"] . '</td>
                                            <td class="row d-flex justify-content-center">
                                                ' . $botonEditar . '
                                            </td>
                                            </tr>';
                                        }
                                    }
                                    ?>
                                </tbody>
                            </table>
                        </div>
                        <!-- /.card-body -->

                        <!-- /.card-body-->
                    </div>
                    <!-- /.card -->
                </div>
                <!-- /.col -->

                <div class="col-md-6">
                    <!-- Line chart -->
                    <div class="card card-primary card-outline">
                        <div class="card-header">
                            <h3 class="card-title">
                                <i class="far fa-chart-bar"></i>
                                Linea de Beneficios
                            </h3>

                            <div class="card-tools">
                                <button type="button" class="btn btn-tool" data-card-widget="collapse">
                                    <i class="fas fa-minus"></i>
                                </button>
                                <button type="button" class="btn btn-tool" data-card-widget="remove">
                                    <i class="fas fa-times"></i>
                                </button>
                            </div>
                        </div>
                        <div class="card-body">
                            <canvas id="Graficobeneficios" width="600" height="400"></canvas>
                        </div>
                        <!-- /.card-body-->
                    </div>
                    <!-- /.card -->

                </div>
                <!-- /.col -->


            </div>
            <!-- /.row -->
        </div><!-- /.container-fluid -->
    </section>
    <!-- /.content -->
</div>
<!-- /.content-wrapper -->

<!-- Modal EDITAR BENEFICIOS-->

<!-- Modal -->
<div id="modalEditarBeneficio" class="modal fade" role="dialog">
    <div class="modal-dialog">

        <!-- Modal content-->
        <div class="modal-content">
            <form method="post">

                <div class="modal-header" style="background: #3c8dbc; color:white;">
                    <h5 class="modal-title" id="exampleModalLabel">Editar Beneficios</h5>
                    <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                        <span aria-hidden="true">&times;</span>
                    </button>
                </div>
                <div class="modal-body">
                    <div class="box-body">
                        <label>Porcentaje de benedicios de compra</label>
                        <div id="divAgregarMoneda" class="input-group mb-3">

                            <input type="number" name="EBeneficioCompra" id="EBeneficioCompra" class="form-control" min="0" max="100" step="0.5" value="0">
                            <div class="input-group-append">
                                <div class="input-group-text">
                                    <span class="fas fa-shopping-cart"></span>
                                </div>
                            </div>

                        </div>
                        <label>Porcentaje de benedicios de venta</label>
                        <div class="input-group mb-3">

                            <input type="number" name="EBeneficioVenta" id="EBeneficioVenta" class="form-control" min="0" max="100" step="0.5" value="0">
                            <div class="input-group-append">
                                <div class="input-group-text">
                                    <span class="fas fa-hand-holding-usd"></span>
                                </div>
                            </div>

                        </div>
                        <div class="input-group mb-3">

                            <input type="hidden" name="EideMoneda" id="EideMoneda" class="form-control">

                        </div>
                    </div>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-outline-secondary pull-left" data-dismiss="modal">Cancelar</button>
                    <button type="submit" class="btn btn-primary">Guardar</button>
                </div>


                <?php
                    $EditarBeneficios = new ControladorMonedas();
                    $EditarBeneficios -> ctrActualizarBeneficios();
                    $DatosGrafico = ControladorMonedas::ctrMostrarBeneficios(null);
                    $arrayValoresCompra=$DatosGrafico[0];
                    $arrayValoresVenta=$DatosGrafico[1];
                ?>

            </form>
        </div>

    </div>
</div>

<script>
    $(function() {
        var speedCanvas3 = document.getElementById("Graficobeneficios");
        var speedData3 = {
            labels: ["1", "2", "3", "4", "5", "6","7", "8", "9", "10", "11", "12"],
            datasets: [{
                    label: "Beneficios por la Compra",
                    data: <?php echo json_encode($arrayValoresCompra); ?>,
                    lineTension: 0,
                    fill: false,
                    borderColor: 'orange',
                    backgroundColor: 'transparent',
                    borderDash: [5, 5],
                    pointBorderColor: 'orange',
                    pointBackgroundColor: 'rgba(255,150,0,0.5)',
                    pointRadius: 5,
                    pointHoverRadius: 10,
                    pointHitRadius: 30,
                    pointBorderWidth: 2,
                    pointStyle: 'rectRounded'
                },
                {
                    label: "Beneficios por la Venta",
                    data: <?php echo json_encode($arrayValoresVenta); ?>,
                    lineTension: 0,
                    fill: false,
                    borderColor: 'red',
                    backgroundColor: 'transparent',
                    borderDash: [5, 5],
                    pointBorderColor: 'red',
                    pointBackgroundColor: 'rgba(255,150,0,0.5)',
                    pointRadius: 5,
                    pointHoverRadius: 10,
                    pointHitRadius: 30,
                    pointBorderWidth: 2,
                    pointStyle: 'rectRounded'
                }
            ]

        };
        var chartOptions3 = {
            legend: {
                display: true,
                position: 'top',
                labels: {
                    boxWidth: 80,
                    fontColor: 'black'
                }
            }
        };
        var lineChart3 = new Chart(speedCanvas3, {
            type: 'line',
            data: speedData3,
            options: chartOptions3
        });
    })
</script>