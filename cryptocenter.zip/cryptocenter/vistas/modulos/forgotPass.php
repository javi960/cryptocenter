<body class="hold-transition login-page">
    <div class="login-box">
        <div class="login-logo">
            <a href="inicio"><b>Crypto</b>Center</a>
        </div>
        <!-- /.login-logo -->
        <div class="card">
            <div class="card-body login-card-body">
                <p class="login-box-msg">¿Has olvidado tu contraseña? Desde esta opcion puedes crear una contraseña nueva.</p>

                <form method="post">
                    <div class="input-group mb-3">
                        <input type="text" name="nombre_usuario" class="form-control" placeholder="nombre de usuario" require>
                        <div class="input-group-append">
                            <div class="input-group-text">
                                <span class="fas fa-user"></span>
                            </div>
                        </div>
                    </div>
                    <div class="input-group mb-3">
                        <input type="email" name="email_usuario" class="form-control" placeholder="email de usuario" require>
                        <div class="input-group-append">
                            <div class="input-group-text">
                                <span class="fas fa-envelope"></span>
                            </div>
                        </div>
                    </div>
                    <div class="row">
                        <div class="col-12">
                            <button type="submit" class="btn btn-primary btn-block">Cambiar Contraseña</button>
                        </div>
                        <!-- /.col -->
                    </div>
                        <?php
                            $recuperarPass = new ControladorUsuarios();
                            $recuperarPass -> ctrComprobarUsuario();
                        ?>
                </form>

                <p class="mt-3 mb-1">
                    <a href="login">Login</a>
                </p>
                <p class="mb-0">
                    <a href="registro" class="text-center">Registrar nuevo miembro</a>
                </p>
            </div>
            <!-- /.login-card-body -->
        </div>
    </div>
    <!-- /.login-box -->