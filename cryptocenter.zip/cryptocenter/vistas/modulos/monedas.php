
<div class="content-wrapper">
    <!-- Content Header (Page header) -->
    <section class="content-header">
        <div class="container-fluid">
            <div class="row mb-2">
                <div class="col-sm-6">
                    <h1>Monedas</h1>
                </div>
            </div>
        </div><!-- /.container-fluid -->
    </section>


    <!-- Main content -->
    <section class="content">
        <div class="container-fluid">
            <div class="row">
                <div class="col-12">
                    <div class="card">
                        <div class="card-header">
                        </div>
                        <!-- /.card-header -->
                        <div class="card-body">
                            <table class="table table-hover" id="TablaMonedas">
                                <thead class="thead-dark">
                                    <tr>
                                        <th>Identificador</th>
                                        <th>Nombre</th>
                                        <th>Valor en Dolares</th>
                                        <th>Más Acciones</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php
                                    $monedas = ControladorMonedas::ctrMostrarMonedas();
                                    $IconosCoin = ControladorMonedas::ctrMostrarIconosMonedas();
                                    $IconoMoneda;
                                    foreach ($monedas as $key => $value) {
                                        $ElArrayMonedas = get_object_vars($value);
                                        $botonSeguir;
                                        foreach ($IconosCoin as $key2 => $valueIconos) {
                                            $ElArrayIconosMonedas = get_object_vars($valueIconos);
                                            if ($ElArrayIconosMonedas["asset_id"] == $ElArrayMonedas["asset_id"]) {
                                                $IconoMoneda = $ElArrayIconosMonedas["url"];
                                                break;
                                            }
                                        }
                                        
                                        if ($ElArrayMonedas["type_is_crypto"] == 1 && isset($ElArrayMonedas["price_usd"])&& $ElArrayMonedas["price_usd"]>0) {
                                            
                                            if ($ElArrayMonedas["price_usd"]>1) {
                                                $valor = round($ElArrayMonedas["price_usd"], 2);
                                            }else {
                                                $valor = $ElArrayMonedas["price_usd"];
                                            }
                                            $valor =str_replace(".",",",$valor);
                                            $coin= ControladorMonedas::ctrMostrarMonedasBase("id_moneda",$ElArrayMonedas["asset_id"]);
                                            if ($coin !=null) {
                                                if ($coin[4] == "1") {
                                                    $botonSeguir = '<button class="btn btn-danger btnQuitarMoneda" 
                                                        Nmoneda="' . $ElArrayMonedas["asset_id"] . '">Eliminar</button>';
                                                }else {
                                                    $botonSeguir = '<button class="btn btn-success btnSeguirMoneda" 
                                                        data-toggle="modal" data-target="#modalAgregarMonedas" 
                                                        Nmoneda="' . $ElArrayMonedas["asset_id"] . '-' . $ElArrayMonedas["name"] . '">Agregar</button>';
                                                }
                                            }else {
                                                $botonSeguir = '<button class="btn btn-success btnSeguirMoneda" 
                                                    data-toggle="modal" data-target="#modalAgregarMonedas" 
                                                    Nmoneda="' . $ElArrayMonedas["asset_id"] . '-' . $ElArrayMonedas["name"] . '">Agregar</button>';
                                            }
                                            ControladorMonedas::ctrDescargarIconoMonedas($ElArrayMonedas["asset_id"],$IconoMoneda);
                                            echo '<tr>
                                            <td><img src="vistas/img/'.$ElArrayMonedas["asset_id"].'.png"> ' . $ElArrayMonedas["asset_id"] . '</td>
                                            <td>' . $ElArrayMonedas["name"] . '</td>
                                            <td>' . $valor . ' $</td>
                                            <td class="row d-flex justify-content-center">
                                                ' . $botonSeguir . '
                                            </td>
                                            </tr>';
                                        }
                                        
                                    }
                                    ?>
                                </tbody>
                            </table>
                        </div>
                        <!-- /.card-body -->
                    </div>
                    <!-- /.card -->
                </div>
                <!-- /.col -->
            </div>
            <!-- /.row -->
        </div>
        <!-- /.container-fluid -->
    </section>
    <!-- /.content -->
</div>



<!-- Modal AGREGAR MONEDAS-->

<!-- Modal -->
<div id="modalAgregarMonedas" class="modal fade" role="dialog">
    <div class="modal-dialog">

        <!-- Modal content-->
        <div class="modal-content">
            <form method="post">

                <div class="modal-header" style="background: #3c8dbc; color:white;">
                    <h5 class="modal-title" id="exampleModalLabel">Agregar Moneda</h5>
                    <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                        <span aria-hidden="true">&times;</span>
                    </button>
                </div>
                <div class="modal-body">
                    <div class="box-body">
                        <label>Porcentaje de benedicios de compra</label>
                        <div id="divAgregarMoneda" class="input-group mb-3">
                            
                            <input type="number" name="beneficioCompra" id="beneficioCompra" class="form-control" min="0" max="100" step="0.5" value="0">
                            <div class="input-group-append">
                                <div class="input-group-text">
                                    <span class="fas fa-shopping-cart"></span>
                                </div>
                            </div>

                        </div>
                        <label>Porcentaje de benedicios de venta</label>
                        <div class="input-group mb-3">
                            
                            <input type="number" name="BeneficioVenta" id="BeneficioVenta" class="form-control" min="0" max="100" step="0.5" value="0">
                            <div class="input-group-append">
                                <div class="input-group-text">
                                    <span class="fas fa-hand-holding-usd"></span>
                                </div>
                            </div>

                        </div>
                        <div class="input-group mb-3">
                            
                            <input type="hidden" name="ideMoneda" id="ideMoneda" class="form-control">
                            <input type="hidden" name="nombreMoneda" id="nombreMoneda" class="form-control">

                        </div>
                    </div>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-outline-secondary pull-left" data-dismiss="modal">Cancelar</button>
                    <button type="submit" class="btn btn-primary">Guardar</button>
                </div>


                <?php

                    $activarMonedas = new ControladorMonedas();
                    $activarMonedas -> ctrActivarMonedas();
                ?>


            </form>
        </div>

    </div>
</div>
