
<div class="content-wrapper">
    <!-- Content Header (Page header) -->
    <section class="content-header">
        <div class="container-fluid">
            <div class="row mb-2">
                <div class="col-sm-6">
                    <h1>Monedas Disponibles</h1>
                </div>
            </div>
        </div><!-- /.container-fluid -->
    </section>


    <!-- Main content -->
    <section class="content">
        <div class="container-fluid">
            <div class="row">
                <div class="col-12">
                    <div class="card">

                        <!-- /.card-header -->
                        <div class="card-body">
                            <table class="table table-hover">
                                <thead class="thead-dark">
                                    <tr>
                                        <th>Identificador</th>
                                        <th>Nombre</th>
                                        <th>Valor en Dolares</th>
                                        <th>Más Acciones</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php
                                    $item = null;

                                    $valor = null;
                                    $coin = ControladorMonedas::ctrMostrarMonedas();
                                    $IconosCoin = ControladorMonedas::ctrMostrarIconosMonedas();
                                    $monedas = ControladorMonedas::ctrMostrarMonedasBase($item, $valor);
                                    foreach ($monedas as $key => $value) {
                                        $item = "n_usuario";
                                        $valor = $_SESSION["usuario"];
                                        $lista = ControladorMonedas::ctrMostrarMonedasSUsuario($item, $valor);
                                        $botonSeguir;
                                        $IconoMoneda;
                                        foreach ($coin as $key2 => $value2) {
                                            $ElArrayMonedas = get_object_vars($value2);
                                            if ($ElArrayMonedas["asset_id"] == $value["id_moneda"]) {
                                                if (isset($ElArrayMonedas["price_usd"])) {
                                                    if ($ElArrayMonedas["price_usd"]>1) {
                                                        $valordolar = round($ElArrayMonedas["price_usd"], 2);
                                                    }else {
                                                        $valordolar = $ElArrayMonedas["price_usd"];
                                                    }
                                                    $valordolar =str_replace(".",",",$valordolar);
                                                }else {
                                                    $valordolar =0;
                                                }                                                
                                            }
                                            
                                        }
                                        foreach ($IconosCoin as $key2 => $valueIconos) {
                                            $ElArrayIconosMonedas = get_object_vars($valueIconos);
                                            if ($ElArrayIconosMonedas["asset_id"] == $value["id_moneda"]) {
                                                $IconoMoneda = $ElArrayIconosMonedas["url"];
                                                break;
                                            }
                                        }
                                        if ($lista != null) {
                                            foreach ($lista as $key3 => $value3) {
                                                if ($value3["id_moneda"] == $value["id_moneda"]) {
                                                    $botonSeguir = '<button class="btn btn-danger btnSigueMoneda" 
                                                        Nmoneda="' . $value["id_moneda"] . '">Eliminar</button>';
                                                    break;
                                                } else {
                                                    $botonSeguir = '<button class="btn btn-success btnSigueMoneda" 
                                                        Nmoneda="' . $value["id_moneda"] . '">Agregar</button>';
                                                }
                                            }
                                        } else {
                                            $botonSeguir = '<button class="btn btn-success btnSigueMoneda" 
                                                        Nmoneda="' . $value["id_moneda"] . '">Agregar</button>';
                                        }

                                        echo '<tr>
                                            <td class = "btnGraficoMonedas" style="cursor:pointer" 
                                            data-toggle="modal" data-target="#modalEditarBeneficio" 
                                            datos="' . $value["id_moneda"] . '-' . $_SESSION['usuario']. '">
                                            <img src="vistas/img/'.$value["id_moneda"].'.png"> ' . $value["id_moneda"] . '</td>
                                            <td>' . $value["nombre"] . '</td>
                                            <td>' . $valordolar . ' $</td>
                                            <td class="row d-flex justify-content-center">
                                                ' . $botonSeguir . '
                                            </td>
                                            </tr>';
                                    }
                                    ?>
                                </tbody >
                            </table>
                        </div>
                        <!-- /.card-body -->
                    </div>
                    <!-- /.card -->
                </div>
                <!-- /.col -->
            </div>
            <!-- /.row -->
        </div>
        <!-- /.container-fluid -->
    </section>
    <!-- /.content -->
</div>


<!-- Modal GRAFICO MONEDA-->

<!-- Modal -->
<div id="modalEditarBeneficio" class="modal fade" role="dialog">
    <div class="modal-dialog">

        <!-- Modal content-->
        <div class="modal-content">
            

            <div class="modal-header" style="background: #3c8dbc; color:white;">
                <h5 class="modal-title" id="exampleModalLabel">Grafico de la Moneda</h5>
                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                    <span aria-hidden="true">&times;</span>
                </button>
            </div>
            <div class="modal-body">
                <div id="divGraficomonedas" class="box-body">
                    <canvas id="Graficomonedas" width="600" height="400"></canvas>
                </div>
            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-outline-secondary pull-left" data-dismiss="modal">Cerrar</button>
            </div>

        </div>

    </div>
</div>

<?php

$seguirMonedas = new ControladorMonedas();
$seguirMonedas->ctrSeguirMonedas();
?>



