<?php

/*
Las líneas 9 a 15 crean el nombre del archivo en caché de acuerdo con el archivo PHP actual. 
Es decir, si estás utilizando un archivo llamado list.php, 
la archivo estático creado por el sistema de caché se llamará cached-list.html.
La línea 16 crea una variable $cachetime que determina la vida de nuestra caché.
*/
$url = $_SERVER["SCRIPT_NAME"];
$break = explode('/', $url);
$file = $break[count($break) - 1];
$urlFinal=$_SERVER["REQUEST_URI"];
$break2 = explode('/', $urlFinal);
$file2 = $break2[count($break2) - 1];
$cachefile = 'cached-'.$file2.'-'.substr_replace($file ,"",-4).'.html';
$cachetime = 18000;
/*
Las líneas 25 a 29 son una declaración condicional que busca un archivo de caché llamado $cachefile. 
Si encuentra el archivo, se inserta un comentario (línea 30) y se incluye el archivo $cachefile. 
Después, el exit detiene la ejecución del script y el archivo se envía al navegador del usuario. 
Lo que significa que si existe el archivo estático, el servidor no interpreta PHP.

La línea 27 crea un búfer si no existe el archivo $cachefile.
Servimos de la cache si es menor que $cachetime*/
if (file_exists($cachefile) && time() - $cachetime < filemtime($cachefile)) {
    echo "<!-- Cached copy, generated ".date('H:i', filemtime($cachefile))." -->";
    readfile($cachefile);
    exit;
}
ob_start(); 
?>