<body class="inicio">
    
<!-- header section starts  -->

<header class="header">

    <a href="#" class="brand-link">
        <img class="brand-image img-circle elevation-3" src="vistas/dist/img/crypto.png" alt=""><h1 class="brand-text font-weight-light">CRYPTO<b>CENTER</b></h1>
    </a>

    <nav class="navbar">
        <a href="inicio">Inicio</a>
        <a href="login">Login</a>
    </nav>

    <div class="icons">
        <div class="fas fa-bars" id="menu-btn"></div>
    </div>

</header>

<!-- header section ends -->

<!-- home section starts  -->

<section class="home" id="home">

    <div class="content">
        <h3>Explora el ecosistema de Cryptocenter</h3>
        <p>Cryptocenter es el lugar más sencillo para comprar y vender criptomonedas. Regístrese y comience hoy mismo.</p>
    </div>

</section>

<!-- home section ends -->

<!-- footer section starts  -->

<section class="footer">

    <div class="credit"><b>Version</b> 1.0 <strong>Copyright &copy; 2021.</div>

</section>

<!-- footer section ends -->

<!-- custom js file link  -->
<script>
    let navbar = document.querySelector('.navbar');

    document.querySelector('#menu-btn').onclick = () =>{
        navbar.classList.toggle('active');
}
</script>