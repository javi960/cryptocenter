<body class="hold-transition login-page">
<div class="login-box">
  <div class="login-logo">
    <a href="inicio"><b>Crypto</b>Center</a>
  </div>
  <!-- /.login-logo -->
  <div class="card">
    <div class="card-body login-card-body">
      <p class="login-box-msg">Inicia Sesión para Acceder a tu Panel</p>

      <form method="post">
        <div class="input-group mb-3">
          <input type="text" name="user" class="form-control" placeholder="Usuario">
          <div class="input-group-append">
            <div class="input-group-text">
              <span class="fas fa-user"></span>
            </div>
          </div>
        </div>
        <div class="input-group mb-3">
          <input type="password" name="password" class="form-control" placeholder="Contraseña">
          <div class="input-group-append">
            <div class="input-group-text">
              <span class="fas fa-lock"></span>
            </div>
          </div>
        </div>
        <div class="row">
          <div class="col-8">
            <div class="icheck-primary">
              <a href="registro" class="text-center">Registrar nuevo miembro</a>
            </div>
          </div>
          <!-- /.col -->
          <div class="col-4">
            <button type="submit" class="btn btn-primary btn-block">Entrar</button>
          </div>
          <!-- /.col -->
          <div class="col-12">
            <a href="forgotPass" class="text-center">He olvidado la contraseña</a>
          </div>
          <!-- /.col -->
        </div>
          <?php
              $login = new ControladorUsuarios();
              $login -> ctrIngresoUsuarios();
          ?>
      </form>


      
  </div>
</div>
<!-- /.login-box -->

