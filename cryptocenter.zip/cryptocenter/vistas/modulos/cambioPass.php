<?php
    if (empty($_GET['nombre_usuario'])) {
        echo '<script>window.location = "forgotPass";</script>';
    }
?>

<body class="hold-transition login-page">
    <div class="login-box">
        <div class="login-logo">
            <a href="inicio"><b>Crypto</b>Center</a>
        </div>
        <!-- /.login-logo -->
        <div class="card">
            <div class="card-body login-card-body">
                <p class="login-box-msg">Introducir la nueva contraseña con la siguiente estructura:</p>
                <ul>
                    <li><small>La contraseña debe tener al entre 8 y 16 caracteres</small></li>
                    <li><small>Al menos un dígito</small></li>
                    <li><small>Al menos una minúscula</small></li>
                    <li><small>Al menos una mayúscula</small></li>
                    <li><small>Al menos un caracter no alfanumérico</small></li>
                </ul>
                <form method="post">
                    <div class="input-group mb-3">
                        <input type="password" name="password" class="form-control" placeholder="Contraseña" pattern="^(?=.*\d)(?=.*[\u0021-\u002b\u003c-\u0040])(?=.*[A-Z])(?=.*[a-z])\S{8,16}$" required>
                        <div class="input-group-append">
                            <div class="input-group-text">
                                <span class="fas fa-lock"></span>
                            </div>
                        </div>
                    </div>
                    <div class="input-group mb-3">
                        <input type="password" name="password2" class="form-control" placeholder="Confirmar Contraseña" pattern="^(?=.*\d)(?=.*[\u0021-\u002b\u003c-\u0040])(?=.*[A-Z])(?=.*[a-z])\S{8,16}$" required>
                        <div class="input-group-append">
                            <div class="input-group-text">
                                <span class="fas fa-lock"></span>
                            </div>
                        </div>
                    </div>
                    <input type="hidden" name="nombre_usuarioC" value="<?php echo $_GET['nombre_usuario']; ?>">
                    <div class="row">
                        <div class="col-12">
                            <button type="submit" class="btn btn-primary btn-block">Cambiar Contraseña</button>
                        </div>
                        <!-- /.col -->
                    </div>
                        <?php
                            $CambiarPass = new ControladorUsuarios();
                            $CambiarPass -> ctrActualizarPassUsuario();
                        ?>
                </form>

                <p class="mt-3 mb-1">
                    <a href="login">Login</a>
                </p>
            </div>
            <!-- /.login-card-body -->
        </div>
    </div>
    <!-- /.login-box -->