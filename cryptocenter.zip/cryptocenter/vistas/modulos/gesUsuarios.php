<div class="content-wrapper">
    <!-- Content Header (Page header) -->
    <section class="content-header">
        <div class="container-fluid">
            <div class="row mb-2">
                <div class="col-sm-6">
                    <h1>Gestor de Usuarios</h1>
                </div>
            </div>
        </div><!-- /.container-fluid -->
    </section>


    <!-- Main content -->
    <section class="content">
        <div class="container-fluid">
            <div class="row">
                <div class="col-12">
                    <div class="card">
                        <div class="card-header">
                            <button class="btn btn-primary" data-toggle="modal" data-target="#modalAgregarUsuarioAdmin">
                                Agregar Usuario
                            </button>
                        </div>
                        <!-- /.card-header -->
                        <div class="card-body">
                            <table class="table table-hover">
                                <thead class="thead-dark">
                                    <tr>
                                        <th>Nombre Usuario</th>
                                        <th>Email</th>
                                        <th>Rol</th>
                                        <th>Validar Usuario</th>
                                        <th>Activo</th>
                                        <th>Más Acciones</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php

                                    $item = null;
                                    $valor = null;
                                    $gusuarios = ControladorUsuarios::ctrMostrarUsuarios($item, $valor);

                                    foreach ($gusuarios as $key => $value) {
                                        $botonActivo;
                                        $botonValidacion;
                                        $botonAcciones;
                                        $mostrarValidacion = ControladorUsuarios::ctrMostrarValidacion($value["n_usuario"]);
                                        if ($mostrarValidacion != null) {
                                            if ($mostrarValidacion['validado'] == 0) {
                                                $botonValidacion = '<button class="btn btn-success btnValidarUsuario"
                                                data-toggle="modal" data-target="#modalValidarUsuario" 
                                                Nusuario="' . $value["n_usuario"] . '">Validar</i></button>
                                                <button class="btn btn-warning btnCancelarValidacion"
                                                Nusuario="' . $value["n_usuario"] . '">No Validar</i></button>';
                                            } else {
                                                $botonValidacion = '<button class="btn btn-secondary" 
                                                    disabled >Activado</i></button>';
                                            }
                                        } else {
                                            $botonValidacion = '<button class="btn btn-secondary" 
                                            disabled >No Validado</i></button>';
                                        }
                                        if ($value["Activo"] == "0") {
                                            $botonActivo = '<button class="btn btn-success btnEstadoUsuario" 
                                                Nusuario="' . $value["n_usuario"] . '">Activar</i></button>';
                                        } else {
                                            $botonActivo = '<button class="btn btn-danger btnEstadoUsuario" 
                                                Nusuario="' . $value["n_usuario"] . '">Desactivar</i></button>';
                                        }
                                        if ($value["rol"]=="Usuario") {
                                            $botonAcciones = '<div class="btn-group">
                                                                <button class="btn btn-warning btnEditarUsuario" Nusuario="'.$value["n_usuario"].'" data-toggle="modal" 
                                                                data-target="#modalEditarUsuario"><i class="fa fa-pen"></i></button>
                                                                <button class="btn btn-danger btnEliminarUsuario" 
                                                                Eusuario="'.$value["n_usuario"].'"><i class="fa fa-times"></i></button>
                                                            </div>';
                                        }elseif ($value["rol"]=="Invitado") {
                                            $botonAcciones = '<div class="btn-group">
                                                                <button class="btn btn-danger btnEliminarUsuario" 
                                                                Eusuario="'.$value["n_usuario"].'"><i class="fa fa-times"></i></button>
                                                            </div>';
                                        } else {
                                            $botonValidacion = 'No se valida';
                                            $botonAcciones = '<div class="btn-group">
                                                                <button class="btn btn-danger btnEliminarUsuario" 
                                                                Eusuario="'.$value["n_usuario"].'"><i class="fa fa-times"></i></button>
                                                            </div>';
                                        }

                                        echo '<tr>
                                            <td>' . $value["n_usuario"] . '</td>
                                            <td>' . $value["email"] . '</td>
                                            <td>' . $value["rol"] . '</td>
                                            <td>' . $botonValidacion . '</td>
                                            <td>' . $botonActivo . '</td>
                                            <td>' . $botonAcciones . '</td>
                                            </tr>';
                                    }
                                    ?>
                                </tbody>
                            </table>
                        </div>
                        <!-- /.card-body -->
                    </div>
                    <!-- /.card -->
                </div>
                <!-- /.col -->
            </div>
            <!-- /.row -->
        </div>
        <!-- /.container-fluid -->
    </section>
    <!-- /.content -->
</div>

<!-- Modal AGREGAR USUARIOS-->

<!-- Modal -->
<div id="modalAgregarUsuarioAdmin" class="modal fade" role="dialog">
    <div class="modal-dialog">

        <!-- Modal content-->
        <div class="modal-content">
            <form method="post">

                <div class="modal-header" style="background: #3c8dbc; color:white;">
                    <h5 class="modal-title">Agregar Administrador</h5>
                    <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                        <span aria-hidden="true">&times;</span>
                    </button>
                </div>
                <div class="modal-body">
                    <div class="box-body">
                        <div class="input-group mb-3">

                            <input type="text" name="usuarioAdmin" id="usuarioAdmin" class="form-control" placeholder="nombre de usuario" required>
                            <div class="input-group-append">
                                <div class="input-group-text">
                                    <span class="fas fa-user"></span>
                                </div>
                            </div>

                        </div>

                        <div class="input-group mb-3">

                            <input type="email" name="emailAdmin" id="emailAdmin" class="form-control" placeholder="Email" required>
                            <div class="input-group-append">
                                <div class="input-group-text">
                                    <span class="fas fa-envelope"></span>
                                </div>
                            </div>

                        </div>

                        <div class="input-group mb-3">

                            <input type="password" name="contraseñaAdmin" id="contraseñaAdmin" class="form-control" placeholder="Contraseña" pattern="^(?=.*\d)(?=.*[\u0021-\u002b\u003c-\u0040])(?=.*[A-Z])(?=.*[a-z])\S{8,16}$" required>
                            <div class="input-group-append">
                                <div class="input-group-text">
                                    <span class="fas fa-lock"></span>
                                </div>
                            </div>

                        </div>

                        <div class="input-group mb-3">

                            <input type="password" name="rcontraseñaAdmin" id="rcontraseñaAdmin" class="form-control" placeholder="Repite la Contraseña" pattern="^(?=.*\d)(?=.*[\u0021-\u002b\u003c-\u0040])(?=.*[A-Z])(?=.*[a-z])\S{8,16}$" required>
                            <div class="input-group-append">
                                <div class="input-group-text">
                                    <span class="fas fa-lock"></span>
                                </div>
                            </div>

                        </div>
                    </div>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-outline-secondary pull-left" data-dismiss="modal">Cancelar</button>
                    <button type="submit" class="btn btn-primary">Guardar</button>
                </div>


                <?php
                $registroAdmin = new ControladorUsuarios();
                $registroAdmin->ctrCrearUsuarioAdmin();
                ?>


            </form>
        </div>

    </div>
</div>


<!-- Modal VER DATOS USUARIOS PARA VALIDAR-->

<!-- Modal -->
<div id="modalValidarUsuario" class="modal fade" role="dialog">
    <div class="modal-dialog">

        <!-- Modal content-->
        <div class="modal-content">
            <form method="POST">

                <div class="modal-header" style="background: #3c8dbc; color:white;">
                    <h5 class="modal-title">Validar Usuario</h5>
                    <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                        <span aria-hidden="true">&times;</span>
                    </button>
                </div>
                <div class="modal-body">
                    <div class="box-body">
                        <input type="hidden" name="Vnusuario" id="Vnusuario" class="form-control">
                        <label>Nombre</label>
                        <div class="input-group mb-3">

                            <input type="text" name="Vnombre" id="Vnombre" class="form-control" disabled>
                            <div class="input-group-append">
                                <div class="input-group-text">
                                    <span class="fas fa-user"></span>
                                </div>
                            </div>
                        </div>
                        <label>Apellido 1</label>
                        <div class="input-group mb-3">

                            <input type="text" name="Vapellido1" id="Vapellido1" class="form-control" disabled>
                            <div class="input-group-append">
                                <div class="input-group-text">
                                    <span class="fas fa-user"></span>
                                </div>
                            </div>
                        </div>
                        <label>Apellido 2</label>
                        <div class="input-group mb-3">

                            <input type="text" name="Vapellido2" id="Vapellido2" class="form-control" disabled>
                            <div class="input-group-append">
                                <div class="input-group-text">
                                    <span class="fas fa-user"></span>
                                </div>
                            </div>
                        </div>
                        <label>DNI</label>
                        <div class="input-group mb-3">

                            <input type="text" name="Vdni" id="Vdni" class="form-control" disabled>
                            <div class="input-group-append">
                                <div class="input-group-text">
                                    <span class="fas fa-user"></span>
                                </div>
                            </div>
                        </div>
                        <label>Telefono</label>
                        <div class="input-group mb-3">

                            <input type="text" name="Vtelefono" id="Vtelefono" class="form-control" disabled>
                            <div class="input-group-append">
                                <div class="input-group-text">
                                    <span class="fas fa-user"></span>
                                </div>
                            </div>
                        </div>
                        <label>Direccion</label>
                        <div class="input-group mb-3">

                            <input type="text" name="Vdireccion" id="Vdireccion" class="form-control" disabled>
                            <div class="input-group-append">
                                <div class="input-group-text">
                                    <span class="fas fa-user"></span>
                                </div>
                            </div>
                        </div>
                        <label>Poblacion</label>
                        <div class="input-group mb-3">

                            <input type="text" name="Vpoblacion" id="Vpoblacion" class="form-control" disabled>
                            <div class="input-group-append">
                                <div class="input-group-text">
                                    <span class="fas fa-user"></span>
                                </div>
                            </div>
                        </div>
                        <label>Provincia</label>
                        <div class="input-group mb-3">

                            <input type="text" name="Vprovincia" id="Vprovincia" class="form-control" disabled>
                            <div class="input-group-append">
                                <div class="input-group-text">
                                    <span class="fas fa-user"></span>
                                </div>
                            </div>
                        </div>
                        <label>País</label>
                        <div class="input-group mb-3">

                            <input type="text" name="Vpais" id="Vpais" class="form-control" disabled>
                            <div class="input-group-append">
                                <div class="input-group-text">
                                    <span class="fas fa-user"></span>
                                </div>
                            </div>
                        </div>
                        <label>Moneda para los fondos</label>
                        <div class="input-group mb-3">

                            <input type="text" name="Vmoneda" id="Vmoneda" class="form-control" disabled>
                            <div class="input-group-append">
                                <div class="input-group-text">
                                    <span class="fas fa-user"></span>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-outline-secondary pull-left" data-dismiss="modal">Cancelar</button>
                    <button type="submit" class="btn btn-primary">Guardar</button>
                </div>


                <?php
                $ValidarUsuario = new ControladorUsuarios();
                $ValidarUsuario->ctrValidarUsuario();
                ?>


            </form>
        </div>

    </div>
</div>

<!-- Modal EDITAR DATOS USUARIOS-->

<!-- Modal -->
<div id="modalEditarUsuario" class="modal fade" role="dialog">
    <div class="modal-dialog">

        <!-- Modal content-->
        <div class="modal-content">
            <form method="POST">

                <div class="modal-header" style="background: #3c8dbc; color:white;">
                    <h5 class="modal-title">Editar Usuario</h5>
                    <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                        <span aria-hidden="true">&times;</span>
                    </button>
                </div>
                <div class="modal-body">
                    <div class="box-body">
                        <input type="hidden" name="Enusuario" id="Enusuario" class="form-control" onkeyup="mayus(this);">
                        <label>Nombre</label>
                        <div class="input-group mb-3">

                            <input type="text" name="Enombre" id="Enombre" class="form-control" onkeyup="mayus(this);">
                            <div class="input-group-append">
                                <div class="input-group-text">
                                    <span class="fas fa-user"></span>
                                </div>
                            </div>
                        </div>
                        <label>Apellido 1</label>
                        <div class="input-group mb-3">

                            <input type="text" name="Eapellido1" id="Eapellido1" class="form-control" onkeyup="mayus(this);">
                            <div class="input-group-append">
                                <div class="input-group-text">
                                    <span class="fas fa-user"></span>
                                </div>
                            </div>
                        </div>
                        <label>Apellido 2</label>
                        <div class="input-group mb-3">

                            <input type="text" name="Eapellido2" id="Eapellido2" class="form-control" onkeyup="mayus(this);">
                            <div class="input-group-append">
                                <div class="input-group-text">
                                    <span class="fas fa-user"></span>
                                </div>
                            </div>
                        </div>
                        <label>DNI</label>
                        <div class="input-group mb-3">

                            <input type="text" name="Edni" id="Edni" class="form-control" onkeyup="mayus(this);">
                            <div class="input-group-append">
                                <div class="input-group-text">
                                    <span class="fas fa-user"></span>
                                </div>
                            </div>
                        </div>
                        <label>Telefono</label>
                        <div class="input-group mb-3">

                            <input type="text" name="Etelefono" id="Etelefono" class="form-control">
                            <div class="input-group-append">
                                <div class="input-group-text">
                                    <span class="fas fa-user"></span>
                                </div>
                            </div>
                        </div>
                        <label>Direccion</label>
                        <div class="input-group mb-3">

                            <input type="text" name="Edireccion" id="Edireccion" class="form-control" onkeyup="mayus(this);">
                            <div class="input-group-append">
                                <div class="input-group-text">
                                    <span class="fas fa-user"></span>
                                </div>
                            </div>
                        </div>
                        <label>Poblacion</label>
                        <div class="input-group mb-3">

                            <input type="text" name="Epoblacion" id="Epoblacion" class="form-control" onkeyup="mayus(this);">
                            <div class="input-group-append">
                                <div class="input-group-text">
                                    <span class="fas fa-user"></span>
                                </div>
                            </div>
                        </div>
                        <label>Provincia</label>
                        <div class="input-group mb-3">

                            <input type="text" name="Eprovincia" id="Eprovincia" class="form-control" onkeyup="mayus(this);">
                            <div class="input-group-append">
                                <div class="input-group-text">
                                    <span class="fas fa-user"></span>
                                </div>
                            </div>
                        </div>
                        <label>País</label>
                        <div class="input-group mb-3">

                            <input type="text" name="Epais" id="Epais" class="form-control" onkeyup="mayus(this);">
                            <div class="input-group-append">
                                <div class="input-group-text">
                                    <span class="fas fa-user"></span>
                                </div>
                            </div>
                        </div>
                        <label>Moneda para los fondos</label>
                        <div class="input-group mb-3">

                            <input type="text" name="Emoneda" id="Emoneda" class="form-control">
                            <div class="input-group-append">
                                <div class="input-group-text">
                                    <span class="fas fa-user"></span>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-outline-secondary pull-left" data-dismiss="modal">Cancelar</button>
                    <button type="submit" class="btn btn-primary" id="Guardar">Guardar</button>
                </div>


                <?php
                $ValidarUsuario = new ControladorUsuarios();
                $ValidarUsuario->ctrActualizarDatosUsuario();
                ?>


            </form>
        </div>

    </div>
</div>


<?php

//$borrarUsuario = new ControladorUsuarios();
//$borrarUsuario->ctrBorrarUsuario();

$activarUsuario = new ControladorUsuarios();
$activarUsuario->ctrActivarUsuario();
$borrarUsuario = new ControladorUsuarios();
$borrarUsuario->ctrBorrarUsuario();
?>