<!-- Content Wrapper. Contains page content -->
<div class="content-wrapper">
    <!-- Content Header (Page header) -->
    <section class="content-header">
        <div class="container-fluid">
            <div class="row mb-2">
                <div class="col-sm-6">
                    <h1>Perfil de Usuario</h1>
                </div>
            </div>
        </div><!-- /.container-fluid -->
    </section>

    <!-- Main content -->
    <section class="content">
        <div class="container-fluid">
            <div class="row">
                <div class="col-md-3">

                    <!-- Profile Image -->
                    <div class="card card-primary card-outline">
                        <div class="card-body box-profile">
                            <div class="text-center">
                                <img class="profile-user-img img-fluid img-circle" src="vistas/dist/img/<?php echo $_SESSION["icono"]; ?>" alt="User profile picture">
                            </div>

                            <h3 class="profile-username text-center"><?php echo $_SESSION["usuario"]; ?></h3>
                            <?php 
                            $datosValidacion = ControladorUsuarios::ctrMostrarTvalidaUsuarios('n_usuario',$_SESSION["usuario"]);
                                if ($_SESSION["rol"]=="Usuario") {
                                    $contadorRanking=0;
                                    $datosRankingPerfil=ControladorMonedas::ctrRanking();
                                    $usuarioPerfil = array_column($datosRankingPerfil, 0);
                                    $beneficioPerfil  = array_column($datosRankingPerfil, 1);
                                    array_multisort($beneficioPerfil, SORT_DESC, $usuarioPerfil, SORT_DESC, $datosRankingPerfil);
                                    foreach ($datosRankingPerfil as $key => $value) {
                                        
                                        $contadorRanking++;
                                    }
                                    $datosUsuario = ControladorUsuarios::ctrMostrarDatosCompletoUsuario($_SESSION["usuario"]);
                                    $cantidadFondos=str_replace(".",",",$datosUsuario['n_fondos']);
                                    echo  
                                        '<ul class="list-group list-group-unbordered mb-3">
                                            <li class="list-group-item">
                                                <b>Ranking</b> <p class="float-right">'.$contadorRanking.'</p>
                                            </li>
                                            <li class="list-group-item">
                                                <b>Fondos</b> <p class="float-right">'.$cantidadFondos.' '.$datosUsuario['moneda_fondo'].'</p>
                                            </li>
                                        </ul>
                                        <div class="card-body row">
                                            <div class="col-md-6">
                                                <button class="btn btn-block btn-outline-secondary btn-sm"
                                                data-toggle="modal" data-target="#modalRetirarFondos">Retirar Fondos</button>
                                            </div>
                                            <div class="col-md-6">
                                                <button class="btn btn-block bg-gradient-info btn-sm"
                                                data-toggle="modal" data-target="#modalAgregarFondos">Agregar Fondos</button>
                                            </div>
                                        </div>';
                                }elseif ($_SESSION["rol"]=="Invitado") {
                                    $datosUsuario = ControladorUsuarios::ctrMostrarUsuarios('n_usuario',$_SESSION["usuario"]);
                                    echo '<p class="text-justify mt-4">Utiliza la pantalla de Datos de Usuario para poder validarte en el sistema
                                    como un usuario de pleno derecho y tener acceso a todas las capacidades de esta herramienta. Una
                                    vez rellenes todos los campos un Usuario Administrador te validará.<p>';
                                }
                            
                            ?>
                        </div>
                        <!-- /.card-body -->
                    </div>
                    <!-- /.card -->
                </div>
                <!-- /.col -->
                <div class="col-md-9">
                    <div class="card">
                        <div class="card-header p-2">
                            <ul class="nav nav-pills">
                            <?php 
                                if ($_SESSION["rol"]=="Usuario") {
                                    echo  
                                        '<li class="nav-item"><a class="nav-link active" href="#DUsuario" data-toggle="tab">Datos de Usuario</a></li>
                                        <li class="nav-item"><a class="nav-link" href="#DCuenta" data-toggle="tab">Datos de la Cuenta</a></li>
                                        <li class="nav-item"><a class="nav-link" href="#OFiscales" data-toggle="tab">Obligaciones Fiscales</a></li>';
                                }elseif ($_SESSION["rol"]=="Invitado") {
                                    echo '<li class="nav-item"><a class="nav-link active" href="#DUsuario" data-toggle="tab">Datos de Usuario</a></li>
                                        <li class="nav-item"><a class="nav-link" href="#DCuenta" data-toggle="tab">Datos de la Cuenta</a></li>';
                                }else {
                                    $datosUsuario = ControladorUsuarios::ctrMostrarUsuarios('n_usuario',$_SESSION["usuario"]);
                                    echo '<li class="nav-item"><a class="nav-link active" href="#DCuenta" data-toggle="tab">Datos de la Cuenta</a></li>';
                                }
                            
                            ?>
                                
                            </ul>
                        </div><!-- /.card-header -->
                        <div class="card-body">
                            <div class="tab-content">
                                <div class="<?php if ($_SESSION["rol"]!="Administrador") {echo 'active';} ?> tab-pane" id="DUsuario">
                                    <form method="POST" class="form-horizontal">
                                        <?php if ($_SESSION["rol"]=="Usuario") {?>
                                            <div class="form-group row">
                                                <label for="nombre" class="col-sm-2 col-form-label">Nombre</label>
                                                <div class="col-sm-10">
                                                    <input type="text" class="form-control" name="nombre" onkeyup="mayus(this);" value="<?php echo $datosUsuario['nombre_u'];?>">
                                                </div>
                                            </div>
                                            <div class="form-group row">
                                                <label for="Apellido1" class="col-sm-2 col-form-label">Apellido 1</label>
                                                <div class="col-sm-10">
                                                    <input type="text" class="form-control" name="Apellido1" onkeyup="mayus(this);" value="<?php echo $datosUsuario['apellido1'];?>">
                                                </div>
                                            </div>
                                            <div class="form-group row">
                                                <label for="Apellido2" class="col-sm-2 col-form-label">Apellido 2</label>
                                                <div class="col-sm-10">
                                                    <input type="text" class="form-control" name="Apellido2" onkeyup="mayus(this);" value="<?php echo $datosUsuario['apellido2'];?>">
                                                </div>
                                            </div>
                                            <div class="form-group row">
                                                <label for="dni" class="col-sm-2 col-form-label">dni</label>
                                                <div class="col-sm-10">
                                                    <input type="text" class="form-control" name="dni" value="<?php echo $datosUsuario['dni'];?>">
                                                </div>
                                            </div>
                                            <div class="form-group row">
                                                <label for="telefono" class="col-sm-2 col-form-label">Numero de telefono</label>
                                                <div class="col-sm-10">
                                                    <input type="number" class="form-control" name="telefono" value="<?php echo $datosUsuario['telefono'];?>">
                                                </div>
                                            </div>
                                            <div class="form-group row">
                                                <label for="direccion" class="col-sm-2 col-form-label">Direccion</label>
                                                <div class="col-sm-10">
                                                    <input type="text" class="form-control" name="direccion" onkeyup="mayus(this);" value="<?php echo $datosUsuario['direccion'];?>">
                                                </div>
                                            </div>
                                            <div class="form-group row">
                                                <label for="poblacion" class="col-sm-2 col-form-label">Poblacion</label>
                                                <div class="col-sm-10">
                                                    <input type="text" class="form-control" name="poblacion" onkeyup="mayus(this);" value="<?php echo $datosUsuario['poblacion'];?>">
                                                </div>
                                            </div>
                                            <div class="form-group row">
                                                <label for="provincia" class="col-sm-2 col-form-label">Provincia</label>
                                                <div class="col-sm-10">
                                                    <input type="text" class="form-control" name="provincia" onkeyup="mayus(this);" value="<?php echo $datosUsuario['provincia'];?>">
                                                </div>
                                            </div>
                                            <div class="form-group row">
                                                <label for="pais" class="col-sm-2 col-form-label">Pais</label>
                                                <div class="col-sm-10">
                                                    <input type="text" class="form-control" name="pais" onkeyup="mayus(this);" value="<?php echo $datosUsuario['pais'];?>">
                                                </div>
                                            </div>
                                            <div class="form-group row">
                                                <label class="col-sm-2 col-form-label">Moneda de fondos</label>
                                                <div class="col-sm-10">
                                                    <select name="MonedaFondos" class="form-control">
                                                        <?php
                                                            $monedas = ControladorMonedas::ctrMostrarMonedas();
                                                            foreach ($monedas as $key => $value) {
                                                                $ElArrayMonedas = get_object_vars($value);
                                                                if ($ElArrayMonedas["type_is_crypto"] == 0) {
                                                                    if ($datosUsuario['moneda_fondo']==$ElArrayMonedas["asset_id"]) {
                                                                        echo '<option value="'.$ElArrayMonedas["asset_id"].'" selected>'.$ElArrayMonedas["asset_id"].'</option>';
                                                                    }else {
                                                                        echo '<option value="'.$ElArrayMonedas["asset_id"].'">'.$ElArrayMonedas["asset_id"].'</option>';
                                                                    }
                                                                    
                                                                }
                                                            }
                                                        ?>
                                                    </select>
                                                </div>
                                            </div>
                                            <input type="hidden" name="nusuario" value="<?php echo $_SESSION["usuario"]; ?>">
                                            
                                            <div class="form-group row">
                                                <div class="offset-sm-2 col-sm-10">
                                                    <button id="botonEnviar" type="submit" class="btn btn-info">Enviar</button>
                                                </div>
                                            </div>

                                        <?php }elseif(($_SESSION["rol"]=="Invitado") && ( isset( $datosValidacion["validado"] ) ? $datosValidacion["validado"] : 1 )) {?>
                                            <?php if(isset($datosValidacion["validado"]) && $datosValidacion["validado"]==3) {?>
                                                <div class="alert alert-danger alert-dismissible">
                                                <h5><i class="icon fas fa-ban"></i> Alerta!</h5>
                                                Aguno de los valores introducidos no ha pasado el filtro del administrador.
                                                Vuelva a introducirlos y compruebe que son correctos.
                                                </div>
                                            <?php }?>
                                            <div class="form-group row">
                                                <label for="nombre" class="col-sm-2 col-form-label">Nombre</label>
                                                <div class="col-sm-10">
                                                    <input type="text" class="form-control" name="nombre" onkeyup="mayus(this);" placeholder="Nombre">
                                                </div>
                                            </div>
                                            <div class="form-group row">
                                                <label for="Apellido1" class="col-sm-2 col-form-label">Apellido 1</label>
                                                <div class="col-sm-10">
                                                    <input type="text" class="form-control" name="Apellido1" onkeyup="mayus(this);" placeholder="Apellido 1">
                                                </div>
                                            </div>
                                            <div class="form-group row">
                                                <label for="Apellido2" class="col-sm-2 col-form-label">Apellido 2</label>
                                                <div class="col-sm-10">
                                                    <input type="text" class="form-control" name="Apellido2" onkeyup="mayus(this);" placeholder="Apellido 2">
                                                </div>
                                            </div>
                                            <div class="form-group row">
                                                <label for="dni" class="col-sm-2 col-form-label">dni</label>
                                                <div class="col-sm-10">
                                                    <input type="text" class="form-control" id="dni" name="dni" pattern="[0-9]{8}[A-Za-z]{1}" onkeyup="mayus(this);" placeholder="dni">
                                                </div>
                                            </div>
                                            <div class="form-group row">
                                                <label for="telefono" class="col-sm-2 col-form-label">Numero de telefono</label>
                                                <div class="col-sm-10">
                                                    <input type="number" class="form-control" name="telefono" placeholder="Numero de telefono">
                                                </div>
                                            </div>
                                            <div class="form-group row">
                                                <label for="direccion" class="col-sm-2 col-form-label">Direccion</label>
                                                <div class="col-sm-10">
                                                    <input type="text" class="form-control" name="direccion" onkeyup="mayus(this);" placeholder="direccion">
                                                </div>
                                            </div>
                                            <div class="form-group row">
                                                <label for="poblacion" class="col-sm-2 col-form-label">Poblacion</label>
                                                <div class="col-sm-10">
                                                    <input type="text" class="form-control" name="poblacion" onkeyup="mayus(this);" placeholder="Poblacion">
                                                </div>
                                            </div>
                                            <div class="form-group row">
                                                <label for="provincia" class="col-sm-2 col-form-label">Provincia</label>
                                                <div class="col-sm-10">
                                                    <input type="text" class="form-control" name="provincia" onkeyup="mayus(this);" placeholder="Provincia">
                                                </div>
                                            </div>
                                            <div class="form-group row">
                                                <label for="pais" class="col-sm-2 col-form-label">Pais</label>
                                                <div class="col-sm-10">
                                                    <input type="text" class="form-control" name="pais" onkeyup="mayus(this);" placeholder="Pais">
                                                </div>
                                            </div>
                                            <div class="form-group row">
                                                <label class="col-sm-2 col-form-label">Moneda de fondos</label>
                                                <div class="col-sm-10">
                                                    <select name="MonedaFondos" class="form-control">
                                                        <?php
                                                            $monedas = ControladorMonedas::ctrMostrarMonedas();
                                                            foreach ($monedas as $key => $value) {
                                                                $ElArrayMonedas = get_object_vars($value);
                                                                if ($ElArrayMonedas["type_is_crypto"] == 0) {
                                                                    echo '<option value="'.$ElArrayMonedas["asset_id"].'">'.$ElArrayMonedas["asset_id"].'</option>';
                                                                }
                                                            }
                                                        ?>
                                                    </select>
                                                </div>
                                            </div>
                                            <input type="hidden" name="nusuario" value="<?php echo $_SESSION["usuario"]; ?>">
                                            
                                            <div class="form-group row">
                                                <div class="offset-sm-2 col-sm-10">
                                                    <button type="submit" id="botonEnviar" class="btn btn-info">Enviar</button>
                                                </div>
                                            </div>

                                        <?php }elseif($_SESSION["rol"]=="Invitado" && $datosValidacion["validado"]==0){ ?>
                                            <div class="divPadre">
                                                <div class="informacion">
                                                    <h3>Validando la Información</h3>

                                                    <p>Espere hasta que un administrador valide la información proporcionada</p>
                                                </div>
                                                <div class="Cargando"></div>
                                            </div>

                                        <?php } 
                                        
                                            $DatosUsuarios = new ControladorUsuarios();
                                            $DatosUsuarios -> ctrDatosUsuario();
                                        
                                        ?>
                                    </form>
                                </div>
                                <!-- /.tab-pane -->
                                <div class="<?php if ($_SESSION["rol"]=="Administrador") {echo 'active';} ?> tab-pane" id="DCuenta">
                                    <form class="form-horizontal" method="POST">
                                        <div class="form-group row">
                                            <label class="col-sm-2 col-form-label">Contraseña</label>
                                            <div class="col-sm-10">
                                                <input type="password" class="form-control" name="passEditar">
                                            </div>
                                        </div>
                                        <div class="form-group row">
                                            <label class="col-sm-2 col-form-label">Confirmar Contraseña</label>
                                            <div class="col-sm-10">
                                                <input type="password" class="form-control" name="pass2Editar">
                                            </div>
                                        </div>
                                        <div class="form-group row">
                                            <label class="col-sm-2 col-form-label">Email</label>
                                            <div class="col-sm-10">
                                                <input type="email" class="form-control" name="emailEditar" value="<?php echo $datosUsuario['email'];?>">
                                            </div>
                                        </div>
                                        <input type="hidden" name="nusuarioEditar" value="<?php echo $_SESSION["usuario"]; ?>">
                                        <div class="form-group row">
                                            <div class="offset-sm-2 col-sm-10">
                                                <button type="submit" class="btn btn-info">Enviar</button>
                                            </div>
                                        </div>
                                            <?php  
                                                $DatosCuentaUsuarios = new ControladorUsuarios();
                                                $DatosCuentaUsuarios -> ctrDatosCuentaUsuario();
                                            
                                            ?>
                                    </form>

                                </div>
                                <!-- /.tab-pane -->

                                <div class="tab-pane" id="OFiscales">
                                    <?php 
                                        if ($datosUsuario['moneda_fondo']=='EUR' && $datosUsuario['pais']=='ESPAÑA') {
                                            $resultado=ControladorMonedas::ctrObligacionesFiscales($_SESSION['usuario']); 
                                            $valorFinal=0;
                                            foreach ($resultado as $key => $value) {
                                                $valoreuros =round($value[1],2);
                                                $valoreuros =str_replace(".",",",$valoreuros);
                                                echo 'La venta de la moneda '.$value[0].' ha obtenido unos beneficios de: '.$valoreuros.' '.$datosUsuario['moneda_fondo'].'<br><br>';
                                                $valorFinal=$valorFinal+round($value[1],2);
                                            }
                                            if ($valorFinal>0 && $valorFinal<6000) {
                                                $valorFinal=$valorFinal*0.19;
                                                $valorFinal=str_replace(".",",",round($valorFinal,2));
                                                echo 'Debes declarar '.$valorFinal.' '.$datosUsuario['moneda_fondo'].' por la venta de tus criptomonedas';
                                            }elseif ($valorFinal>=6000 && $valorFinal<50000) {
                                                $valorFinal=$valorFinal*0.21;
                                                $valorFinal=round($valorFinal,2);
                                                $valorFinal=str_replace(".",",",$valorFinal);
                                                echo 'Debes declarar '.$valorFinal.' '.$datosUsuario['moneda_fondo'].' por la venta de tus criptomonedas';
                                            }elseif ($valorFinal>=50000) {
                                                $valorFinal=$valorFinal*0.23;
                                                $valorFinal=round($valorFinal,2);
                                                $valorFinal=str_replace(".",",",$valorFinal);
                                                echo 'Debes declarar '.$valorFinal.' '.$datosUsuario['moneda_fondo'].' por la venta de tus criptomonedas';
                                            }else {
                                                echo 'No es necesario declarar nada debido a que la venta de todas tus criptomonedas no ha generado ningún beneficio';
                                            }
                                        }else {
                                            echo 'Funcionalidad solo para ususarios de España que utilicen el Euro para las compras';
                                        }
                                        
                                    ?>
                                </div>
                                <!-- /.tab-pane -->
                            </div>
                            <!-- /.tab-content -->
                        </div><!-- /.card-body -->
                    </div>
                    <!-- /.card -->
                </div>
                <!-- /.col -->
            </div>
            <!-- /.row -->
        </div><!-- /.container-fluid -->
    </section>
    <!-- /.content -->
</div>
<!-- /.content-wrapper -->

<!-- Modal AGREGAR FONDOS-->

<!-- Modal -->
<div id="modalAgregarFondos" class="modal fade" role="dialog">
    <div class="modal-dialog">

        <!-- Modal content-->
        <div class="modal-content">
            <form method="post">

                <div class="modal-header" style="background: #3c8dbc; color:white;">
                    <h5 class="modal-title" id="exampleModalLabel">Agregar Fondos</h5>
                    <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                        <span aria-hidden="true">&times;</span>
                    </button>
                </div>
                <div class="modal-body">
                    <div class="box-body">
                        <label>¿Cuanto dinero deseas cargar?</label>
                        <div class="input-group mb-3">                            
                            <input type="number" name="AFondos" class="form-control" min="0" value="0">
                            <div class="input-group-append">
                                <div class="input-group-text">
                                    <span class="fas fa-coins"></span>
                                </div>
                            </div>
                        </div>
                        <label>Nombre del titular de la Tarjeta</label>
                        <div class="input-group mb-3">                            
                            <input type="text" name="nombreTarjeta" class="form-control">
                            <div class="input-group-append">
                                <div class="input-group-text">
                                    <span class="fas fa-credit-card"></span>
                                </div>
                            </div>
                        </div>
                        <label>Número de la Tarjeta</label>
                        <div class="input-group mb-3">                            
                            <input type="number" name="numeroTarjeta" class="form-control" placeholder="1234567890123456">
                            <div class="input-group-append">
                                <div class="input-group-text">
                                    <span class="fas fa-credit-card"></span>
                                </div>
                            </div>
                        </div>
                        <label>CVC</label>
                        <div class="input-group mb-3">                            
                            <input type="number" name="CVC" class="form-control">
                            <div class="input-group-append">
                                <div class="input-group-text">
                                    <span class="fas fa-credit-card"></span>
                                </div>
                            </div>
                        </div>
                        <input type="hidden" name="nusuario" value="<?php echo $_SESSION['usuario']; ?>">
                    </div>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-outline-secondary pull-left" data-dismiss="modal">Cancelar</button>
                    <button type="submit" class="btn btn-primary">Aceptar</button>
                </div>


                <?php

                    $CargarFondos = new ControladorFondos();
                    $CargarFondos -> ctrCargarFondos();
                ?>


            </form>
        </div>

    </div>
</div>

<!-- Modal RETIRAR FONDOS-->

<!-- Modal -->
<div id="modalRetirarFondos" class="modal fade" role="dialog">
    <div class="modal-dialog">

        <!-- Modal content-->
        <div class="modal-content">
            <form method="post">

                <div class="modal-header" style="background: #3c8dbc; color:white;">
                    <h5 class="modal-title" id="exampleModalLabel">Retirar Fondos</h5>
                    <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                        <span aria-hidden="true">&times;</span>
                    </button>
                </div>
                <div class="modal-body">
                    <div class="box-body">
                        <label>¿Cuanto dinero deseas retirar?</label>
                        <div class="input-group mb-3">                            
                            <input type="number" name="RFondos" class="form-control" min="0" value="0">
                            <div class="input-group-append">
                                <div class="input-group-text">
                                    <span class="fas fa-coins"></span>
                                </div>
                            </div>
                        </div>
                        <label>Número de la Tarjeta</label>
                        <div class="input-group mb-3">                            
                            <input type="number" name="numeroRTarjeta" class="form-control" placeholder="1234567890123456">
                            <div class="input-group-append">
                                <div class="input-group-text">
                                    <span class="fas fa-credit-card"></span>
                                </div>
                            </div>
                        </div>
                        <input type="hidden" name="nusuario" value="<?php echo $_SESSION['usuario']; ?>">
                    </div>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-outline-secondary pull-left" data-dismiss="modal">Cancelar</button>
                    <button type="submit" class="btn btn-primary">Aceptar</button>
                </div>


                <?php

                    $RetirarFondos = new ControladorFondos();
                    $RetirarFondos -> ctrRetirarFondos();
                ?>


            </form>
        </div>

    </div>
</div>