<div class="content-wrapper">
    <!-- Content Header (Page header) -->
    <section class="content-header">
        <div class="container-fluid">
            <div class="row mb-2">
                <div class="col-sm-6">
                    <h1>Ranking</h1>
                </div>
            </div>
        </div><!-- /.container-fluid -->
    </section>


    <!-- Main content -->
    <section class="content">
        <div class="container-fluid">
            <div class="row">
                <div class="col-12">
                    <div class="card">

                        <!-- /.card-header -->
                        <div class="card-body">
                            <table class="table table-hover">
                                <thead class="thead-dark">
                                    <tr>
                                        <th>Posicion</th>
                                        <th>Usuario</th>
                                        
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php
                                        $contador = 0;
                                        $datosRanking = ControladorMonedas::ctrRanking();
                                        $usuario = array_column($datosRanking, 0);
                                        $beneficio  = array_column($datosRanking, 1);
                                        array_multisort($beneficio, SORT_DESC, $usuario, SORT_DESC, $datosRanking);
                                        foreach ($datosRanking as $key => $value) {
                                            $contador++;
                                            echo '<tr>
                                                <td>' . $contador . '</td>
                                                <td>' .$value[0]. '</td>
                                                </tr>';
                                        }
                                    ?>
                                </tbody>
                            </table>
                        </div>
                        <!-- /.card-body -->
                    </div>
                    <!-- /.card -->
                </div>
                <!-- /.col -->
            </div>
            <!-- /.row -->
        </div>
        <!-- /.container-fluid -->
    </section>
    <!-- /.content -->
</div>

<!-- Modal COPIAR USUARIO-->

<!-- Modal -->
<div id="modalCopiarUsuario" class="modal fade" role="dialog">
    <div class="modal-dialog">

        <!-- Modal content-->
        <div class="modal-content">
            <form method="post">

                <div class="modal-header" style="background: #3c8dbc; color:white;">
                    <h5 class="modal-title" id="exampleModalLabel">Copiar Cartera del Usuario</h5>
                    <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                        <span aria-hidden="true">&times;</span>
                    </button>
                </div>
                <div class="modal-body">
                    <div class="box-body">
                        <label>¿Cuanto dinero deseas retirar?</label>
                        <div class="input-group mb-3">                            
                            <input type="number" name="RFondos" class="form-control" min="0" value="0">
                            <div class="input-group-append">
                                <div class="input-group-text">
                                    <span class="fas fa-coins"></span>
                                </div>
                            </div>
                        </div>
                        <label>Número de la Tarjeta</label>
                        <div class="input-group mb-3">                            
                            <input type="number" name="numeroRTarjeta" class="form-control" placeholder="1234567890123456">
                            <div class="input-group-append">
                                <div class="input-group-text">
                                    <span class="fas fa-credit-card"></span>
                                </div>
                            </div>
                        </div>
                        <input type="hidden" name="nusuario" value="<?php echo $_SESSION['usuario']; ?>">
                    </div>
                </div>
                


                <?php

                    //$RetirarFondos = new ControladorFondos();
                    //$RetirarFondos -> ctrRetirarFondos();
                ?>


            </form>
            <div class="modal-footer">
                <button type="button" class="btn btn-outline-secondary pull-left" data-dismiss="modal">Cancelar</button>
            </div>
        </div>

    </div>
</div>