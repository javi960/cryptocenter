<?php
/*
Si el archivo en caché al que hace referencia $cachefile no se encuentra en el servidor, 
este código se ejecutará y creará el archivo de caché en sí.

Como resultado, la próxima vez que se solicite la página, el archivo estático $cachefile 
se servirá al navegador del usuario en lugar de ejecutar todo el archivo PHP.
Crea el archivo de cache*/
$cached = fopen($cachefile, 'w');
fwrite($cached, ob_get_contents());
fclose($cached);
ob_end_flush(); // Envia la salida al navegador
?>