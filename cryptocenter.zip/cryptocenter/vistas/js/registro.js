document.addEventListener("DOMContentLoaded", function() {
    document.getElementById("registroUsuario").addEventListener('submit', validarFormulario); 
});

function validarFormulario(evento) {
    evento.preventDefault();
    var usuario = document.getElementById('usuario').value;
    if(usuario.length == 0) {
        alert('No has escrito nada en el usuario');
        return;
    }
    var clave = document.getElementById('contraseña').value;
    if (clave.length < 8) {
        alert('La clave no es válida');
        return;
    }
    this.submit();
}

$("#usuario").blur(function(){
    
    var usuarioR = $(this).val();
    if (usuarioR!="") {
        var datos = new FormData();
        datos.append("usuarioR", usuarioR);
        $.ajax({
            url: "ajax/Usuario.ajax.php",
            method: "POST",
            data: datos,
            cache: false,
            contentType: false,
            processData: false,
            dataType: "json",
            success: function(respuesta) {
                if (respuesta==true) {
                    $("#usuario").addClass("is-invalid");
                    $("#usuario").removeClass("is-valid");
                }else{
                    $("#usuario").addClass("is-valid");
                    $("#usuario").removeClass("is-invalid");
                }
                
            }
        });
    }
    
});

$("#email").blur(function(){    
    var emailR = $(this).val();
    if (emailR!="") {
        var datos = new FormData();
        datos.append("emailR", emailR);
        $.ajax({
            url: "ajax/Usuario.ajax.php",
            method: "POST",
            data: datos,
            cache: false,
            contentType: false,
            processData: false,
            dataType: "json",
            success: function(respuesta) {
                if (respuesta==true) {
                    $("#email").addClass("is-invalid");
                    $("#email").removeClass("is-valid");
                }else{
                    $("#email").addClass("is-valid");
                    $("#email").removeClass("is-invalid");
                }
                
            }
        });
    }
    
});