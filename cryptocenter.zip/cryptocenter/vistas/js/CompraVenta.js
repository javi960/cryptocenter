$(".btnComprarMoneda").click(function() {
    
    var Nmoneda = $(this).attr("Nmoneda");
    
    $('#idmoneda').val(Nmoneda);
})

$(".btnVenderMoneda").click(function() {
    
    var VNmoneda = $(this).attr("Nmoneda");
    
    $('#Vidmoneda').val(VNmoneda);
    var datos = new FormData();
    datos.append("VNmoneda", VNmoneda);
    datos.append("usuario", $('#nombreUsuario').text());

    $.ajax({
        url: "ajax/Monedas.ajax.php",
        method: "POST",
        data: datos,
        cache: false,
        contentType: false,
        processData: false,
        dataType: "json",
        success: function(respuesta) {
            var Valor=respuesta['cantidad'].replace(".",",");
            $('#cantidadM').empty();
            $('#cantidadM').append("Tienes "+Valor+" Monedas");
            $('#VentaMoneda').prop("max",respuesta['cantidad']);
            
        }
    });
    
})