

/*

    ACTIVAR O DESACTIVAR MONEDAS PARA EL USUARIO DESDE LA PANTALLA DE MONEDAS DEL ADMINISTRADOR

*/

$(".btnSeguirMoneda").click(function() {
    
    var Nmoneda = $(this).attr("Nmoneda");
    var division=Nmoneda.split("-");
    $('#ideMoneda').val(division[0]);
    $('#nombreMoneda').val(division[1]);
})

$(".btnQuitarMoneda").click(function() {
    
    var Nmoneda = $(this).attr("Nmoneda");    
    var datos = new FormData();
    datos.append("Nmoneda", Nmoneda);

    $.ajax({
        url: "ajax/Monedas.ajax.php",
        method: "POST",
        data: datos,
        cache: false,
        contentType: false,
        processData: false,
        dataType: "json",
        success: function(respuesta) {
            
            window.location = "index.php?ruta=monedas";
            
        }
    });
})

/*

    SEGUIR O NO SEGUIR MONEDAS PARA EL USUARIO DESDE LA PANTALLA DEL USUARIO

*/

$(".btnSigueMoneda").click(function() {
    
    var Nmoneda = $(this).attr("Nmoneda");
    
    Swal.fire({
        title: '¿Está seguro de la acción?',
        text: "Si no lo está puede cancelar la acción",
        type: 'warning',
        showCancelButton: true,
        confirmButtonColor: '#3085d6',
        cancelButtonColor: '#d33',
        cancelButtonText: 'Cancelar',
        confirmButtonText: 'Si'
    }).then((result)=>{
        if(result.value){
            
            window.location = "index.php?ruta=mpUsuario&Nmoneda="+Nmoneda;
        }
    });
})


$(".btnEditarBeneficio").click(function() {
    
    var Identificadormoneda = $(this).attr("Identificadormoneda");    
    var datos = new FormData();
    datos.append("Identificadormoneda", Identificadormoneda);

    $.ajax({
        url: "ajax/Monedas.ajax.php",
        method: "POST",
        data: datos,
        cache: false,
        contentType: false,
        processData: false,
        dataType: "json",
        success: function(respuesta) {
            
            $('#EBeneficioCompra').val(respuesta["BenfCompra"]);
            $('#EBeneficioVenta').val(respuesta["BenfVenta"]);
            $('#EideMoneda').val(respuesta["id_moneda"]);
            
        }
    });
})

$(".btnDescargarMoneda").click(function() {
    
    var Dmoneda = $(this).attr("Dmoneda");   
    var datos = new FormData();
    datos.append("Dmoneda", Dmoneda);

    $.ajax({
        url: "ajax/Monedas.ajax.php",
        method: "POST",
        data: datos,
        cache: false,
        contentType: false,
        processData: false,
        dataType: "json",
        success: function(respuesta) {
            
            window.location = "index.php?ruta=billetera";
            
        }
    });
})

$(".btnGraficoMonedas").click(function() {
    
    var datos1 = $(this).attr("datos");    
    var datos = new FormData();
    datos.append("datos", datos1);

    $.ajax({
        url: "ajax/Monedas.ajax.php",
        method: "POST",
        data: datos,
        cache: false,
        contentType: false,
        processData: false,
        dataType: "json",
        success: function(respuesta) {
            
            var fechas=[];
            var valores=[];
            for (let index = 0; index < respuesta.length; index++) {
                const valorUsar = respuesta[index];
                result = valorUsar['time_period_start'].toLocaleString();
                var res = result.split("T")[0];
                var fech= res.split("-");
                var reordenarfecha=fech[2]+"-"+fech[1];
                fechas.push(reordenarfecha);
                valores.push(valorUsar['rate_open']);
            }
            
            $(function() {
                $('#Graficomonedas').remove();
                $('#divGraficomonedas').append('<canvas id="Graficomonedas" width="600" height="400"><canvas>');
                var speedCanvas3 =null;
                var speedCanvas3 = document.getElementById("Graficomonedas");
                var speedData3 = {
                    labels: fechas,
                    datasets: [{
                            label: "Valor de la Moneda Segun la Moneda que Usas",
                            data: valores,
                            lineTension: 0,
                            fill: false,
                            borderColor: 'orange',
                            backgroundColor: 'transparent',
                            borderDash: [5, 5],
                            pointBorderColor: 'orange',
                            pointBackgroundColor: 'rgba(255,150,0,0.5)',
                            pointRadius: 5,
                            pointHoverRadius: 10,
                            pointHitRadius: 30,
                            pointBorderWidth: 2,
                            pointStyle: 'rectRounded'
                        }
                    ]
        
                };
                var chartOptions3 = {
                    legend: {
                        display: true,
                        position: 'top',
                        labels: {
                            boxWidth: 80,
                            fontColor: 'black'
                        }
                    }
                };
                var lineChart3 = new Chart(speedCanvas3, {
                    type: 'line',
                    data: speedData3,
                    options: chartOptions3
                });
            })
            
        }
    });
})

