/*

    ACTIVAR O DESACTIVAR  USUARIO

*/

$(".btnEstadoUsuario").click(function() {
    
    var Nusuario = $(this).attr("Nusuario");
    
    Swal.fire({
        title: '¿Está seguro de la acción?',
        text: "Si no lo está puede cancelar la acción",
        type: 'warning',
        showCancelButton: true,
        confirmButtonColor: '#3085d6',
        cancelButtonColor: '#d33',
        cancelButtonText: 'Cancelar',
        confirmButtonText: 'Si'
    }).then((result)=>{
        if(result.value){
            
            window.location = "index.php?ruta=gesUsuarios&Nusuario="+Nusuario;
        }
    });
})

$(".btnValidarUsuario").click(function() {
    
    var Nusuario = $(this).attr("Nusuario");
    var datos = new FormData();
    datos.append("Nusuario", Nusuario);
    $.ajax({
        url: "ajax/Usuario.ajax.php",
        method: "POST",
        data: datos,
        cache: false,
        contentType: false,
        processData: false,
        dataType: "json",
        success: function(respuesta) {
            
            $("#Vnusuario").val(respuesta["n_usuario"]);
            $("#Vnombre").val(respuesta["nombre_u"]);
            $("#Vapellido1").val(respuesta["apellido1"]);
            $("#Vapellido2").val(respuesta["apellido2"]);
            $("#Vdni").val(respuesta["dni"]);
            $("#Vtelefono").val(respuesta["telefono"]);
            $("#Vdireccion").val(respuesta["direccion"]);
            $("#Vpoblacion").val(respuesta["poblacion"]);
            $("#Vprovincia").val(respuesta["provincia"]);
            $("#Vpais").val(respuesta["pais"]);
            $("#Vmoneda").val(respuesta["moneda_fondo"]);
            
        }
    });
})

$(".btnCancelarValidacion").click(function() {
    
    var Eusuario = $(this).attr("Nusuario");
    var datos = new FormData();
    datos.append("Eusuario", Eusuario);
    $.ajax({
        url: "ajax/Usuario.ajax.php",
        method: "POST",
        data: datos,
        cache: false,
        contentType: false,
        processData: false,
        dataType: "json",
        success: function(respuesta) {
            window.location = "index.php?ruta=gesUsuarios";
            
        }
    });
})

$(".btnEditarUsuario").click(function() {
    
    var Nusuario = $(this).attr("Nusuario");
    var datos = new FormData();
    datos.append("Nusuario", Nusuario);
    $.ajax({
        url: "ajax/Usuario.ajax.php",
        method: "POST",
        data: datos,
        cache: false,
        contentType: false,
        processData: false,
        dataType: "json",
        success: function(respuesta) {
            
            $("#Enusuario").val(respuesta["n_usuario"]);
            $("#Enombre").val(respuesta["nombre_u"]);
            $("#Eapellido1").val(respuesta["apellido1"]);
            $("#Eapellido2").val(respuesta["apellido2"]);
            $("#Edni").val(respuesta["dni"]);
            $("#Etelefono").val(respuesta["telefono"]);
            $("#Edireccion").val(respuesta["direccion"]);
            $("#Epoblacion").val(respuesta["poblacion"]);
            $("#Eprovincia").val(respuesta["provincia"]);
            $("#Epais").val(respuesta["pais"]);
            $("#Emoneda").val(respuesta["moneda_fondo"]);
            
        }
    });
})

/*

    ELIMINAR USUARIO

*/

$(".btnEliminarUsuario").click(function() {
    
    var Eusuario = $(this).attr("Eusuario");
    
    Swal.fire({
        title: '¿Está seguro de la acción?',
        text: "Si no lo está puede cancelar la acción",
        type: 'warning',
        showCancelButton: true,
        confirmButtonColor: '#3085d6',
        cancelButtonColor: '#d33',
        cancelButtonText: 'Cancelar',
        confirmButtonText: 'Si, Borrar'
    }).then((result)=>{
        if(result.value){
            
            window.location = "index.php?ruta=gesUsuarios&Eusuario="+Eusuario;
        }
    });
})


function mayus(e) {
    e.value = e.value.toUpperCase();
}


$("#dni, #Edni").blur(function(){
    var dni = $(this).val();
    var numero
    var letr
    var letra
    var expresion_regular_dni
    
    expresion_regular_dni = /^\d{8}[a-zA-Z]$/;
    if(expresion_regular_dni.test (dni) == true){
        numero = dni.substr(0,dni.length-1);
        letr = dni.substr(dni.length-1,1);
        numero = numero % 23;
        letra='TRWAGMYFPDXBNJZSQVHLCKET';
        letra=letra.substring(numero,numero+1);
        if (letra!=letr.toUpperCase()) {
            $("#dni, #Edni").addClass("is-invalid");
            $("#dni, #Edni").removeClass("is-valid");
            $("#botonEnviar, #Guardar").prop('disabled', true);
        }else{
            var datos = new FormData();
            datos.append("dni", dni);
            $.ajax({
                url: "ajax/Usuario.ajax.php",
                method: "POST",
                data: datos,
                cache: false,
                contentType: false,
                processData: false,
                dataType: "json",
                success: function(respuesta) {
                    if (respuesta==true) {
                        $("#dni, #Edni").addClass("is-invalid");
                        $("#dni, #Edni").removeClass("is-valid");
                        $("#botonEnviar, #Guardar").prop('disabled', true);
                    }else{
                        $("#dni, #Edni").addClass("is-valid");
                        $("#dni, #Edni").removeClass("is-invalid");
                        $("#botonEnviar, #Guardar").prop('disabled', false);
                    }
                    
                }
            });
        }
    }else{
        $("#dni, #Edni").addClass("is-invalid");
        $("#dni, #Edni").removeClass("is-valid");
        $("#botonEnviar, #Guardar").prop('disabled', true);
    }
    
});

